#!/usr/bin/env node
/**
 * ShowDoc 文档获取脚本
 * 通过 ShowDoc API 获取页面内容并转换为 Markdown 格式
 */

import https from 'https';
import http from 'http';
import { URL } from 'url';

function fetchShowdocPage(apiUrl, pageId, cookies = null) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(apiUrl);
    const isHttps = parsedUrl.protocol === 'https:';
    const lib = isHttps ? https : http;

    const postData = `page_id=${encodeURIComponent(pageId)}`;

    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (isHttps ? 443 : 80),
      path: parsedUrl.pathname + parsedUrl.search,
      method: 'POST',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      },
      rejectUnauthorized: false, // skip SSL verification
    };

    if (cookies) {
      options.headers['Cookie'] = cookies;
    }

    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Failed to parse JSON: ${e.message}\nRaw: ${data.slice(0, 500)}`));
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

/**
 * 从 ShowDoc URL 中提取域名和页面 ID
 * URL 格式: http://domain:port/web/#/cat_id/page_id
 */
function parseShowdocUrl(urlStr) {
  const url = new URL(urlStr);
  const domain = url.host;

  // 从 fragment 中提取 page_id
  const match = url.hash.match(/\/(\d+)$/);
  if (!match) {
    throw new Error(`无法从 URL 中提取页面 ID: ${urlStr}`);
  }

  const pageId = match[1];
  const apiUrl = `http://${domain}/server/index.php?s=/api/page/info`;

  return { apiUrl, pageId };
}

/**
 * 将 ShowDoc API 返回的数据转换为 Markdown
 */
function convertToMarkdown(data) {
  if (data.code !== 0) {
    throw new Error(`API Error: ${data.message || 'Unknown error'}`);
  }

  const page = data.data?.page || {};
  const title = page.page_title || 'Untitled';
  const content = page.page_content || '';

  return `# ${title}\n\n${content}`;
}

// CLI
async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.error('用法: node fetch_page.mjs <showdoc_url> [--cookie "PHPSESSID=xxx"]');
    console.error('   或: node fetch_page.mjs --api-url <url> --page-id <id> [--cookie "xxx"]');
    process.exit(1);
  }

  let apiUrl, pageId, cookie;

  if (args[0].startsWith('http')) {
    // URL 模式
    const parsed = parseShowdocUrl(args[0]);
    apiUrl = parsed.apiUrl;
    pageId = parsed.pageId;
    const cookieIdx = args.indexOf('--cookie');
    if (cookieIdx !== -1) cookie = args[cookieIdx + 1];
  } else if (args[0] === '--api-url') {
    // 直接参数模式
    apiUrl = args[1];
    const pageIdIdx = args.indexOf('--page-id');
    if (pageIdIdx === -1) {
      console.error('错误: 缺少 --page-id 参数');
      process.exit(1);
    }
    pageId = args[pageIdIdx + 1];
    const cookieIdx = args.indexOf('--cookie');
    if (cookieIdx !== -1) cookie = args[cookieIdx + 1];
  } else {
    console.error('未知参数');
    process.exit(1);
  }

  try {
    const data = await fetchShowdocPage(apiUrl, pageId, cookie);
    const md = convertToMarkdown(data);
    console.log(md);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}

main();
